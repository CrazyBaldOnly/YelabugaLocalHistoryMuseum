<?php
	// include ('dbinfo.php');
	// $result = $mysqli->query($query);

    // Вывод через while
    // while ($value = $result->fetch_assoc()) {
    //     echo "<pre>";
    //     print_r($value);	
    //     echo "</pre>";
    // }

    // Вывод через foreach
    // foreach ($result as $value){
    //     echo "<pre>";
    //     print_r($value);	
    //     // echo $value['tag_name'];
    //     echo "</pre>";
    // }

    include ('dbinfo.php');
    function tags_output($query){
        global $mysqli;
        $result = $mysqli->query($query);
        $rowsCount = $result->num_rows; // количество полученных строк
        echo "<p>Получено строк: $rowsCount</p>";
        // Вывод через while
        echo '<table class="table"><tr><th>Id</th><th>Тэг</th>';
        while ($value = $result->fetch_array()) {
            echo "<tr>";
                echo "<td>" . $value["tag_id"] . "</td>";
                echo "<td>" . $value["tag_name"] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }

    function types_output($query){
        global $mysqli;
        $result = $mysqli->query($query);
        $rowsCount = $result->num_rows; // количество полученных строк
        echo "<p>Получено строк: $rowsCount</p>";
        // Вывод через while
        echo '<table class="table"><tr><th>Id</th><th>Тип</th>';
        while ($value = $result->fetch_array()) {
            echo "<tr>";
                echo "<td>" . $value["type_id"] . "</td>";
                echo "<td>" . $value["type_name"] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    function types(){
        global $mysqli;
        $query = 'SELECT * FROM `types`';
        
        $result = $mysqli->query($query);
        while ($value = $result->fetch_array()){
            $types = $value['type_name'];
            echo '<option value=' .$types. '>' .$types.'</option>';
        }
    }
?>