<link href= "ALstyles.css" rel= "stylesheet" type= "text/css"/>
<form action="" method="post">
	<center>
		<div class="logo">
			<img src="logo.jpeg">
		</div>	
		<div class="container">
			<input id="login" type="text" placeholder="Введите имя пользователя" name="uname" required><br>
			<input id="pasw" type="password" placeholder="Введите пароль" name="psw" required><br>
			<button type="submit">Войти</button>
		</div>
		<div class="buttons">
			<form  action="" method="POST">
				<p><a href="/tags1.html">Настройка тегов</a></p>
				<p><a href="/types1.html">Настройка типов</a></p>
				<p><a href="/files1.html">Добавление документов</a></p>
			</form>
		</div>
	</center>
		
</form> 